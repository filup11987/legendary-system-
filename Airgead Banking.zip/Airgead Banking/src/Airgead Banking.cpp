//============================================================================
// Name        : Airgead.cpp
// Author      : Phillip Reid II
// Version     : 10/4/2020
// Copyright   : Your copyright notice
// Description : Airgead Banking Investment Calculator
//============================================================================

#include <iostream>
#include <iomanip>
using namespace std;
int main() {
	float initInv, monDep, AnuInt, months, years;//set variables
	float totalAm, intAmt, yearTotInt;//set variables
	cout << "************\n";
	cout << "**** Data Input ****\n";//Input prompt
	cout << "Initial Investment Amount: \n";
	cout << "Monthly Deposit: \n";
	cout << "Annual Interest: \n";
	cout << "Number of years: \n";
	system("PAUSE");
	cout << "***********\n";
	cout << "**** Data Input ****\n";//Input Values
	cout << "Initial Investment Amount: $";
		cin >> initInv;
	cout << "Monthly Deposit: $";
		cin >> monDep;
	cout << "Annual Interest: %";
		cin >> AnuInt;
	cout << "Number of years: ";
		cin >> years;
	months = years * 12;
	system("PAUSE");
	totalAm = initInv;
	//calculate the balance and interest with no monthly deposits
	cout << "\nBalance and Interest Without Additional Monthly Deposits\n";
	cout << "==============================================================\n";
	cout << "Year\t\tYear End Balance\tYear End Earned Interest\n";
	cout << "--------------------------------------------------------------\n";
	for (int i = 0; i < years; i++) {
		intAmt = (totalAm) * (AnuInt / 100);
		totalAm = totalAm + intAmt;
		cout << (i + 1) << "\t\t$" << fixed << setprecision(2) << totalAm << "\t\t\t$" << intAmt << "\n";
	}
	totalAm = initInv;
	//calculate balance and interest with monthly deposits
	cout << "\n\nBalance and Interest With Additional Monthly Deposits\n";
	cout << "==============================================================\n";
	cout << "Year\t\tYear End Balance\tYear End Earned Interest\n";
	cout << "--------------------------------------------------------------\n";
	for (int i = 0; i < years; i++) {
		yearTotInt = 0;
		for (int j = 0; j < 12; j++) {
			intAmt = (totalAm + monDep) * ((AnuInt / 100) / 12);
			yearTotInt = yearTotInt + intAmt;
			totalAm = totalAm + monDep + intAmt;
		}
		cout << (i + 1) << "\t\t$" << fixed << setprecision(2) << totalAm << "\t\t\t$" << yearTotInt << "\n";
	}
	return 0;
}
